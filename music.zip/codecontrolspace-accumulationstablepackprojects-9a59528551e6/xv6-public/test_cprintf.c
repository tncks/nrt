#include "types.h"
#include "stat.h"
#include "user.h"
#include <stdlib.h>
int main(int argc, char* argv[]) {

  for(;;){}
  return 0;
  //exit();
}
