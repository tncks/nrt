#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "spinlock.h"
#include "proc.h"

int QUIETMODE_ = 0;  // choose 0 or 1 (hard code for test) //current: 0 (mode not enabled)
// debugging global var <- should be removed later 


struct table ptable;

static struct proc *initproc;

int nextpid = 1;
extern void forkret(void);
extern void trapret(void);

static void wakeup1(void *chan);
// Added recently but under test.
struct proc* GetMainThread(struct proc *p);
int NumberOfThread(struct proc *main_t);
int thread_create(thread_t *thread, void *(*start_routine)(void *), void *arg);
void thread_exit(void *retval);
int thread_join(thread_t thread, void **retval);
int isLWP(struct proc *t);
void ExitLWP(int arg);

//
//
//



void
pinit(void)
{
  initlock(&ptable.lock, "ptable");
}

// Must be called with interrupts disabled
int
cpuid() {
  return mycpu()-cpus;
}

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu*
mycpu(void)
{
  int apicid, i;
  
  if(readeflags()&FL_IF)
    panic("mycpu called with interrupts enabled\n");
  
  apicid = lapicid();
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i) {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc*
myproc(void) {
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

//PAGEBREAK: 32
// Look in the process table for an UNUSED proc.
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == UNUSED)
      goto found;

  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
  p->isthread = 0;

  release(&ptable.lock);

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
  p->tf = (struct trapframe*)sp;

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
  p->context->eip = (uint)forkret;

  return p;
}

//PAGEBREAK: 32
// Set up first user process.
void
userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();  // normal

  p->tgid = p->pid;  // diff (should be tested later)
  p->process = p;    // diff 
  initlock(&p->vlock, "vlock"); // diff

  p->threadcount = 1; // diff
  
  initproc = p;   // normal 

  acquire(&p->vlock);

  if((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  release(&p->vlock);
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0;  // beginning of initcode.S

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");


  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);

  p->state = RUNNABLE;

  release(&ptable.lock);
}

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  struct proc *main_t;
  uint theap;
  uint sz;
  struct proc *curproc = myproc();

  acquire(&curproc->process->vlock);

  sz = curproc->process->sz;
  main_t = GetMainThread(curproc);
  theap = main_t->theap;
  if(n > 0){
    if((theap = allocuvm(main_t->pgdir, theap, theap + n)) == 0){
      release(&curproc->process->vlock);
      return -1;
    }
  } else if(n < 0){
    if((theap = deallocuvm(main_t->pgdir, theap, theap + n)) == 0){
      release(&curproc->process->vlock);
      return -1;
    }
  }
  curproc->process->sz = sz;
  main_t->theap = theap;

  release(&curproc->process->vlock);

  switchuvm(curproc);
  return 0;
}

// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();
  struct spinlock *valock;

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Thread group
  np->tgid = np->pid;
  np->process = np;

  cprintf("proc.c ~ initlock\n");
  initlock(&np->vlock, "vlock");
  //valock = &(curproc->process->vlock);
  //acquire(valock);
  cprintf("proc.c ~ acquire(valock)\n");

  // Copy process state from proc.
  if((np->pgdir = copyuvm(proc->pgdir, proc->theap, proc->bstack)) == 0){
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    //release(valock);
    return -1;
  }
  np->sz = curproc->process->sz;
  np->sz = curproc->sz;  // Added recently
  np->theap = curproc->theap;
  np->bstack = curproc->bstack;
  np->parent = curproc; // Added recently
  //release(valock);
  np->parent = curproc->process;
  *np->tf = *curproc->tf;

  // Clear %eax so that fork returns 0 in the child.
  np->tf->eax = 0;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  pid = np->pid;

  acquire(&ptable.lock);

  np->state = RUNNABLE;
  np->threadcount = 1;

  release(&ptable.lock);

  return pid;
}

// Added recently
// Return 1 if current process is LWP.
int
isLWP(struct proc *t)
{
  struct proc *p;
  
  if(proc->mthread_p != 0){
    return 1;
  }
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->mthread_p == t)
      return 1;
  }
  return 0;

}

// Added recently
// arg = 0 exit all, arg = 1 let current proc.
void
ExitLWP(int arg)
{
  struct proc *p, *child_p, *main_t;
  int fd;
#ifdef D_ExitLWP
  cprintf("[ExitLWP] Start...\n");
#endif
  main_t = GetMainThread(proc);
#ifdef D_ExitLWP
  cprintf("[ExitLWP] main_t : %d\n", main_t->pid);
#endif
  // To prevent interrupt when cleaning up other PCB
  //pushcli();
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->mthread_p == main_t || p == main_t){
      if(arg == 1 && p == proc) {
#ifdef D_ExitLWP
        cprintf("[ExitLWP] Pass current process..\n");
#endif
        continue;
      }
      // Because when exec call, the memory should remain.
      // When the exec done, call exitLWP again, then clean mem.
      if(arg == 1 && p == main_t){
#ifdef D_ExitLWP
        cprintf("[ExitLWP] Pass main thread process..\n");
#endif
        continue;
      }
#ifdef D_ExitLWP
      cprintf("[ExitLWP] Find one pid :%d\n", p->pid);
#endif
      // Close all open files.
      for(fd = 0; fd < NOFILE; fd++){
        if(p->ofile[fd]){
          fileclose(p->ofile[fd]);
          p->ofile[fd] = 0;
        }
      }

      begin_op();
      iput(p->cwd);
      end_op();
      p->cwd = 0;

      acquire(&ptable.lock);

      wakeup1(p->parent);

      // Pass abandoned child process to init,
      // Pass abandoned thread to main_t
      for(child_p = ptable.proc; child_p < &ptable.proc[NPROC]; child_p++){
        if(child_p->parent == proc){
          if(child_p->isthread != 1){
            child_p->parent = initproc;
            if(child_p->state == ZOMBIE)
              wakeup1(initproc);
          }
          else if(child_p->isthread == 1){
            child_p->parent = main_t;
            if(child_p->state == ZOMBIE)
              wakeup1(main_t);
          }
        }
      }
#ifdef D_ExitLWP
      cprintf("[ExitLWP] pid : %d Change State ZOMBIE\n", p->pid);
#endif
      p->state = ZOMBIE;
      release(&ptable.lock);
#ifdef D_ExitLWP
      //cprintf("[ExitLWP] release ptable lock success\n");
#endif
    }
  }
  //popcli();
  if(arg == 1){
    return;
  }
#ifdef D_ExitLWP
  cprintf("[ExitLWP] f1\n");
  if(proc->state == ZOMBIE){
    cprintf("[ExitLWP] current state : ZOMBIE\n");
  }
#endif
  acquire(&ptable.lock);
  sched();
}


// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void
exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

  // LWP exit. never return.
  if(isLWP(proc) == 1){
    ExitLWP(0);
  }

  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  /*
  // some thread from group might be sleeping in wait() 
  wakeup1(curproc->process);

  curproc->process->threadcount -= 1; */

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc){
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

// Wait for a child process (with all its threads)
// to exit and return its pid.
// *a* child process -> all threads of one child
// Return -1 if this process has no children.
int
wait(void)
{
  struct proc *p, *t;
  int havekids, pid;
  // int found, tgid; 
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);
  for(;;){
    // Scan through table looking for a child process which has exited
    havekids = 0;
    //found = 0;
    //tgid = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE) {
        // Found one. 

        // Clear thread. 
        for(t = ptable.proc; t < &ptable.proc[NPROC]; t++){
          if(t->mthread_p == p && t->state == ZOMBIE){
            kfree(t->kstack);
            t->kstack = 0;
            t->pid = 0;
            t->parent = 0;
            t->name[0] = 0;
            t->killed = 0;
            t->state = UNUSED;
            t->tret = 0;
            t->isthread = 0;
            t->mthread_p = 0;
            t->theap = 0;
            t->bstack = KERNBASE - PGSIZE;
          }
        }
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        p->tret = 0;
        p->isthread = 0;
        p->mthread_p = 0;
        p->theap = 0;
        p->bstack = KERNBASE - PGSIZE;
        release(&ptable.lock);
        return pid;

      }
      /*if (p->process->threadcount == 0){
        // the one to be harvested
        tgid = p->tgid;
        found = 1;
        break;
      } */
    }
    
    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    } 

    // Added recently 
    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(proc, &ptable.lock);  //DOC: wait-sleep

    
    /*  Test later  if else here necessary? confirm again need  
    if(!found){
      // Wait for children to exit.  (See wakeup1 call in proc_exit.)
      sleep(curproc->process, &ptable.lock);  //DOC: wait-sleep
    }
    else{
      break;
    } */
  }

  // test need 
  // temporary disabled code 
  /*
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->tgid != tgid)
      continue;
    // assert: this *p* is to be reaped
    if(p->state == ZOMBIE){
      if(p->pid == p->tgid && p->process == p){
        freevm(p->pgdir);
      }
      kfree(p->kstack);
      p->kstack = 0;
      p->context = 0;
      p->pid = 0;
      p->tgid = 0;
      p->parent = 0;
      p->name[0] = 0;
      p->killed = 0;
      p->state = UNUSED;
      p->process = 0;
      p->pgdir = 0;
      p->threadcount = 0;
    } else{
      panic("undead");
    }
  }
  release(&ptable.lock);
  return tgid;  */
}

//PAGEBREAK: 42
// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  c->proc = 0;
   
  cprintf("cpusc is running11\n"); 
  int stupid_count = 1;
  for(;;){
    if((++stupid_count) % 100000 == 0)
      ; //cprintf("RR\n");
    stupid_count %= 300000;
    // Enable interrupts on this processor.
    sti();

    // Loop over process table looking for process to run.
    acquire(&ptable.lock);
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->state != RUNNABLE)
        continue;

      // Switch to chosen process.  It is the process's job
      // to release ptable.lock and then reacquire it
      // before jumping back to us.
      c->proc = p;
      switchuvm(p);
      p->state = RUNNING;

      swtch(&(c->scheduler), p->context);
      switchkvm();

      // Process is done running for now.
      // It should have changed its p->state before coming back.
      c->proc = 0;
    }
    release(&ptable.lock);

  }
}

// Enter scheduler.  Must hold only ptable.lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->ncli, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&ptable.lock))
    panic("sched ptable.lock");
  if(mycpu()->ncli != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(readeflags()&FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  acquire(&ptable.lock);  //DOC: yieldlock
  myproc()->state = RUNNABLE;
  sched();
  release(&ptable.lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);

  if (first) {
    // Some initialization functions must be run in the context
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  if(p == 0)
    panic("sleep");

  if(lk == 0)
    panic("sleep without lk");

  // Must acquire ptable.lock in order to
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if(lk != &ptable.lock){  //DOC: sleeplock0
    acquire(&ptable.lock);  //DOC: sleeplock1
    release(lk);
  }
  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  if(lk != &ptable.lock){  //DOC: sleeplock2
    release(&ptable.lock);
    acquire(lk);
  }
}

//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

// Kill the thread with the given pid.
// thread won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

//PAGEBREAK: 36
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}

// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
int
clone(int (*fn)(void *, void*), void *arg1, void *arg2, 
      void *stack, int flags)
{
return 3;
/*
  int i, pid;
  uint *sp;
  struct proc *np;
  struct proc *curproc = myproc();

  // anyway, not touching anything below stack - 12
  if ((uint)(stack - 4096) >= curproc->process->sz || (uint)(stack) > curproc->process->sz)
    return -1;

  // page-aligned stack: malloc() does not guarentee,
  // if ((PGROUNDDOWN((int)stack) != (int)stack))
  //  return -1;

  //stack += 4096; // top of the stack

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Thread group
  np->tgid = curproc->tgid;
  np->process = curproc->process;

  initlock(&np->vlock, "vlock");
  struct spinlock *valock = &(curproc->process->vlock);
  acquire(valock);
  np->pgdir = curproc->pgdir;
  np->sz = 0;
  release(valock);

  // one more thread using same address space
  // invariant: when exiting this system call
  // the threadcount will be equal to the number
  // of threads using the pgdir of the thread group
  // leader
  np->threadcount = 0;

  np->parent = curproc->parent;
  *np->tf = *curproc->tf;

  // lay out the stack for user program
  sp = (uint *)stack;
  sp -= 1;
  *sp = (uint)arg2;
  sp -= 1;
  *sp = (uint)arg1;
  sp -= 1;
  *sp = (uint)0xffffffff; // temperory, should be die()

  // In child, begin execution from fn, args are in stack
  np->tf->eip = (uint)fn;
  np->tf->esp = (uint)sp;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  pid = np->pid;

  acquire(&ptable.lock);

  if (curproc->killed) {
    np->state = ZOMBIE;
  } else {
    np->state = RUNNABLE;
    curproc->process->threadcount += 1;
  }

  release(&ptable.lock);

  return pid;*/
}

// Make the current thread zombie
// Do not return
// A dead thread remains in ZOMBIE
// state till some thread from the 
// parent process calls wait on it
void
die(void)
{
/*
  struct proc *curproc = myproc();

  if(curproc == initproc)
    panic("init exiting");

  acquire(&ptable.lock);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit"); */
}

// if thread with pid = *pid* is in the same thread group
// wait of it to exit, and reap it
// if thread is the thread group leader, do not reap it
// return the *pid* If no such thread exists, return -1
int
join(int pid)
{
return 3;
/*
  struct proc *p;
  struct proc *curproc = myproc();

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      if(p->tgid == curproc->tgid && p->process == curproc->process){
        break;
      }
      else{
        release(&ptable.lock);
        return -1;
      }
    }
  }
  
  if(p->pid != pid){
    release(&ptable.lock);
    return -1;
  }

  while(p->state != ZOMBIE){
    if(curproc->killed){
      release(&ptable.lock);
      return -1;
    }
    sleep(curproc->process, &ptable.lock);
  }

  if(p->tgid != p->pid && p != p->process){
    kfree(p->kstack);
    p->kstack = 0;
    p->context = 0;
    p->pid = 0;
    p->tgid = 0;
    p->parent = 0;
    p->name[0] = 0;
    p->killed = 0;
    p->state = UNUSED;
    p->process = 0;
    p->pgdir = 0;
    p->threadcount = 0;
  }

  release(&ptable.lock);
  return pid; */
}

// Return main thread of LWP.
struct proc *
GetMainThread(struct proc *p){
  if(p->isthread != 1){      
    return p;
  }
  return GetMainThread(p->parent);
}

// Return number of thread including main thread.
int
NumberOfThread(struct proc *main_t)
{
  struct proc *p;
  int num = 0;
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->isthread && p->mthread_p == main_t)
      num++;
  }
  return num + 1;
}

int 
thread_create(thread_t *thread, void *(*start_routine)(void *), void *arg)
{
  uint sp, ustack[3+MAXARG+1], bstack;
  struct proc *np;
  int i;
#ifdef TDEBUG
  if(!QUIETMODE_)
    cprintf("[CREATE]\n");
#endif

  // Allocate process for thread. kstack is also allocated at here.
  if((np = allocproc()) == 0){
#ifdef TDEBUG
    cprintf("allocproc fail\n");
#endif
    return -1;
  }
 
  // Allocate thread(process) user stack.
  bstack = proc->bstack;
  bstack = PGROUNDDOWN(bstack);
  bstack -= 2*PGSIZE;
  if((sp = allocuvm(proc->pgdir, bstack, bstack + 2*PGSIZE)) == 0){
#ifdef TDEBUG
    cprintf("allocuvm failure. sp : %d\n", sp);
#endif
    return -1;
  }
  clearpteu(proc->pgdir, (char*)(sp - 2*PGSIZE));
  //sp = sz;

  // Push argument .
  ustack[0] = 0xffffffff;
  ustack[1] = (uint)arg;

  sp -= 2 * 4;
    
  if(copyout(proc->pgdir, sp, ustack, 2*4) < 0){
#ifdef TDEBUG
    cprintf("copy ustack failure\n");
#endif
    deallocuvm(proc->pgdir, bstack + 2*PGSIZE, bstack);
    return -1;
  }

  np->pgdir = proc->pgdir;
  np->sz = proc->sz;
  np->theap = proc->theap;
  np->bstack = bstack;
  proc->bstack = bstack;
  np->parent = proc;
  
  *np->tf = *proc->tf;
  np->isthread = 1;
  np->mthread_p = GetMainThread(proc);
  //Stride setting
  /*
  acquire(&stable.lock);
  if(proc->isstride == 1){
    if(set_thread_cpu_share(np, 0) == 0) {
      panic("thread cpu share panic!");
      return -1;
    }
    //set_all_thread_stride(np->mthread_p, NumberOfThread(np->mthread_p));
  }
  release(&stable.lock);
  */ // temporary disabled for test
  np->tf->eip = (uint)start_routine;

  np->tf->esp = sp;
 
  // Copy parent's file descriptor
  for(i = 0; i < NOFILE; i++)
    if(proc->ofile[i])
      np->ofile[i] = filedup(proc->ofile[i]);
  np->cwd = idup(proc->cwd);

  safestrcpy(np->name, proc->name, sizeof(proc->name));

  *thread = np->pid;

  acquire(&ptable.lock);

  np->state = RUNNABLE;

  release(&ptable.lock);

#ifdef TDEBUG
  if(!QUIETMODE_)
    cprintf("[CREATE] Done! pid : %d parent : %d\n", np->pid, np->parent->pid);
#endif
  return 0;
}

void
thread_exit(void *retval)
{
  struct proc *p;
  int fd;
#ifdef TDEBUG
  //cprintf("[EXIT]\n");
#endif
  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(proc->ofile[fd]){
      fileclose(proc->ofile[fd]);
      proc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(proc->cwd);
  end_op();
  proc->cwd = 0;

  acquire(&ptable.lock);

  // Parent might be sleeping in wait();
  wakeup1(proc->parent);

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    // Find child process
    if(p->parent == proc){
      if(p->isthread != 1){
        p->parent = initproc;        
        if(p->state == ZOMBIE)
          wakeup1(initproc);
      }

      else if(p->isthread == 1){
        p->parent = p->mthread_p;
        if(p->state == ZOMBIE)
          wakeup1(p->mthread_p);
      }
    }
  }

  // Jump into the scheduler, never to return.
  proc->state = ZOMBIE;
  proc->tret = retval;
  //proc->parent->hasthread -= 1;
#ifdef TDEBUG
  if(!QUIETMODE_)
    cprintf("[EXIT] Done! pid : %d parent : %d\n", proc->pid, proc->parent->pid);
#endif
  sched();
  panic("zombie exit thread");
}
int 
thread_join(thread_t thread, void **retval)
{
  struct proc *p, *p1;
  int havethread;
  uint bstack;
#ifdef TDEBUG
  if(!QUIETMODE_)
    cprintf("[JOIN] join thread pid : %d\n", (int)thread);
#endif
  acquire(&ptable.lock);
  for(;;){
    havethread = 0;   
    // Scan through table looking for exited thread.
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != proc || p->pid != (int)thread)
        continue;
      havethread = 1;

      if(p->state == ZOMBIE){
        // Found one.
        *retval = p->tret;

        // Reclaim allocated thread stack from sz to sz of thread 
        // which exited already (state is ZOMBIE). 
        // If exited thread isn't top of thread stack, 
        // then just end with ret value.

        // Main base stack.
        bstack = proc->bstack;
        // Only stack erea. Ignore heap called by sbrk.
        // bstack = PGROUNDDOWN(tsz); 
        // If exited thread is top of thread stack
        if(p->bstack == bstack){
#ifdef TDEBUG
  if(!QUIETMODE_) {
          cprintf("[JOIN]Free pid : %d, parent : %d, mt : %d\n",p->pid,p->parent->pid,p->mthread_p->pid);
  }
#endif
          kfree(p->kstack);
          p->kstack = 0;
          deallocuvm(p->pgdir, p->bstack + 2*PGSIZE, p->bstack);
          p->parent = 0;
          p->name[0] = 0;
          p->killed = 0;
          p->state = UNUSED;
          p->tret = 0;
          p->isthread = 0;
          p->mthread_p = 0;
          p->theap = 0;
          p->bstack = KERNBASE - PGSIZE;
       
          for(;;){
            // Find next base stack.
            bstack += 2*PGSIZE;
            // tsz = PGROUNDUP(tsz);
            if(bstack >= KERNBASE - PGSIZE){
              break;
            }
            
            // Find thread with bstack
            for(p1 = ptable.proc; p1 < &ptable.proc[NPROC]; p1++){
              if(p1->bstack == bstack && p1->parent == proc && p1->isthread == 1) {
                break;
              }
            }
  
            if(p1->state != ZOMBIE)
              break;
#ifdef TDEBUG
  if(!QUIETMODE_) {
            cprintf("[JOIN]Free2(%d) pid : %d, parent : %d, mt : %d\n",p->pid,p1->pid,p1->parent->pid,p1->mthread_p->pid);
}
#endif
            kfree(p1->kstack);
            p1->kstack = 0;
            deallocuvm(p1->pgdir, p1->bstack + 2*PGSIZE, p1->bstack);
            p1->pid = 0;
            p1->parent = 0;
            p1->name[0] = 0;
            p1->killed = 0;
            p1->state = UNUSED;
            p1->tret = 0;
            p1->isthread = 0;
            p1->mthread_p = 0;
            p1->theap = 0;
            p1->bstack = KERNBASE - PGSIZE;

          }
          p->pid = 0;
          proc->bstack = bstack;
        }
        //
        release(&ptable.lock);
        return 0;     
      }
    }

    if(!havethread || proc->killed){
      release(&ptable.lock);
      return -1;
    }
    sleep(proc, &ptable.lock);    

  }
  return -1;
}
//         
//         
//         
//         
//         
//         
//         
//         
//         
//         
//         
//         
